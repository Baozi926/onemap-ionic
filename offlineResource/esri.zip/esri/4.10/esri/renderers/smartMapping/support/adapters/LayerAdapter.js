// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define("require exports ../../../../core/tsSupport/declareExtendsHelper ../../../../core/tsSupport/decorateHelper ../../../../core/Accessor ../../../../core/Loadable ../../../../core/accessorSupport/decorators".split(" "),function(h,k,e,c,f,g,b){return function(d){function a(a){return d.call(this)||this}e(a,d);c([b.property()],a.prototype,"geometryType",void 0);c([b.property()],a.prototype,"objectIdField",void 0);c([b.property()],a.prototype,"outFields",void 0);c([b.property()],a.prototype,"supportsSQLExpression",
void 0);c([b.property()],a.prototype,"hasQueryEngine",void 0);return a=c([b.subclass()],a)}(b.declared(f,g))});