// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define("require exports ../ClassBreaksRenderer ../HeatmapRenderer ../Renderer ../SimpleRenderer ../UniqueValueRenderer".split(" "),function(g,a,b,c,d,e,f){Object.defineProperty(a,"__esModule",{value:!0});a.types={key:"type",base:d,typeMap:{heatmap:c,simple:e,"unique-value":f,"class-breaks":b}}});