// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports","./PointSizeAlgorithm","./PointSizeFixedSizeAlgorithm","./PointSizeSplatAlgorithm"],function(e,a,b,c,d){Object.defineProperty(a,"__esModule",{value:!0});a.pointSizeAlgorithmTypes={key:"type",base:b.default,typeMap:{"fixed-size":c.default,splat:d.default}}});