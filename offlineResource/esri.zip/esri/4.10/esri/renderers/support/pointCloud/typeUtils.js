// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define("require exports ../../PointCloudClassBreaksRenderer ../../PointCloudRenderer ../../PointCloudRGBRenderer ../../PointCloudStretchRenderer ../../PointCloudUniqueValueRenderer".split(" "),function(g,a,b,c,d,e,f){Object.defineProperty(a,"__esModule",{value:!0});a.types={key:"type",base:c,typeMap:{"point-cloud-class-breaks":b,"point-cloud-rgb":d,"point-cloud-stretch":e,"point-cloud-unique-value":f}}});