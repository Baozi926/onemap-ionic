// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports"],function(b,a){Object.defineProperty(a,"__esModule",{value:!0});a.wgs84Radius=6378137;a.wgs84InverseFlattening=298.257223563;a.wgs84Flattening=1/a.wgs84InverseFlattening;a.wgs84PolarRadius=a.wgs84Radius*(1-a.wgs84Flattening);a.wgs84Eccentricity=.0818191908426215});