// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports","./tsSupport/extendsHelper","./tsSupport/decorateHelper","./Message"],function(a,k,g,l,h){a=function(a){function b(c,d,e){var f=a.call(this,c,d,e)||this;return f instanceof b?f:new b(c,d,e)}g(b,a);return b}(h);a.prototype.type="warning";return a});