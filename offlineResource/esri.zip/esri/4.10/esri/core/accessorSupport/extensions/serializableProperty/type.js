// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports"],function(c,b){Object.defineProperty(b,"__esModule",{value:!0});b.isCollection=function(a){return!!a&&a.prototype&&a.prototype.declaredClass&&0===a.prototype.declaredClass.indexOf("esri.core.Collection")}});