// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports","../metadata"],function(e,a,b){Object.defineProperty(a,"__esModule",{value:!0});a.aliasOf=function(a){return function(c,d){b.getPropertyMetadata(c,d).aliasOf=a}}});