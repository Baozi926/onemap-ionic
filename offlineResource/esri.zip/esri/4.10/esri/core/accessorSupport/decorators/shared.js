// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports"],function(d,a){Object.defineProperty(a,"__esModule",{value:!0});a.shared=function(a){return function(b,c){b[c]=a}}});