// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports","../metadata"],function(b,a,c){Object.defineProperty(a,"__esModule",{value:!0});a.autoDestroy=function(){return function(a,d,b){c.getMetadata(a).autoDestroy=!0;return a[d]}}});