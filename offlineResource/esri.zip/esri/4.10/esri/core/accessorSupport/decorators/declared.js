// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports"],function(d,b){Object.defineProperty(b,"__esModule",{value:!0});b.declared=function(b){for(var c=[],a=1;a<arguments.length;a++)c[a-1]=arguments[a];a=function(){return this||{}};a.__bases__=[b].concat(c);return a}});