// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports","dojo/on"],function(c,a,b){Object.defineProperty(a,"__esModule",{value:!0});a.on=b;a.once=b.once;a.pausable=b.pausable;a.emit=b.emit});