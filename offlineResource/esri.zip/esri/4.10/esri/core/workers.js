// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports","./workers/workers"],function(d,a,c){Object.defineProperty(a,"__esModule",{value:!0});for(var b in c)a.hasOwnProperty(b)||(a[b]=c[b])});