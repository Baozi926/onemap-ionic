// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["./declare"],function(b){return b(null,{declaredClass:"esri.core.OperationBase",type:"not implemented",label:"not implemented",constructor:function(a){a=a||{};a.label&&(this.label=a.label)},performUndo:function(){console.log("performUndo has not been implemented")},performRedo:function(){console.log("performRedo has not been implemented")}})});