// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["../Viewpoint","../core/JSONSupport"],function(a,b){return b.createSubclass({declaredClass:"esri.portal.Bookmark",properties:{description:{type:String,json:{write:!0}},thumbnailSource:{type:String,json:{write:!0}},title:{type:String,json:{write:!0}},viewpoint:{type:a,json:{write:!0}}}})});