// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define("require exports ../core/tsSupport/declareExtendsHelper ../core/tsSupport/decorateHelper ../core/Accessor ../core/accessorSupport/decorators".split(" "),function(g,h,e,c,f,b){return function(d){function a(a){a=d.call(this)||this;a.nextQueryParams=null;a.queryParams=null;a.results=null;a.total=null;return a}e(a,d);c([b.property()],a.prototype,"nextQueryParams",void 0);c([b.property()],a.prototype,"queryParams",void 0);c([b.property()],a.prototype,"results",void 0);c([b.property()],a.prototype,
"total",void 0);return a=c([b.subclass("esri.portal.PortalQueryResult")],a)}(b.declared(f))});