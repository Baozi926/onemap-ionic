// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["../../core/Accessor"],function(a){return a.createSubclass({declaredClass:"esri.tasks.support.LegendLayer",properties:{layerId:null,subLayerIds:null,title:null}})});