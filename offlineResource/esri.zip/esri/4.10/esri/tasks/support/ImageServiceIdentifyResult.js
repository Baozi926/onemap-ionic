// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["../../core/JSONSupport","../../geometry/Point","./FeatureSet"],function(a,b,c){return a.createSubclass({declaredClass:"esri.tasks.support.ImageServiceIdentifyResult",properties:{catalogItemVisibilities:null,catalogItems:{value:null,type:c},location:{value:null,type:b},name:null,objectId:null,properties:null,value:null}})});