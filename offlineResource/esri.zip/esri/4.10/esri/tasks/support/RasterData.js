// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["../../core/JSONSupport"],function(a){return a.createSubclass({declaredClass:"esri.tasks.support.RasterData",properties:{format:null,itemId:{value:null,json:{read:{source:"itemID"},write:{target:"itemID"}}},url:null}})});