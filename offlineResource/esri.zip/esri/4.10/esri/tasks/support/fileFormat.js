// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["require","exports","../../core/kebabDictionary"],function(a,b,c){Object.defineProperty(b,"__esModule",{value:!0});a=c({PDF:"pdf",PNG32:"png32",PNG8:"png8",JPG:"jpg",GIF:"gif",EPS:"eps",SVG:"svg",SVGZ:"svgz"});b.fromJSON=a.fromJSON.bind(a);b.toJSON=a.toJSON.bind(a)});