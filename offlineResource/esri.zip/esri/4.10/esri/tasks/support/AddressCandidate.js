// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define(["../../core/JSONSupport","../../geometry/Extent","../../geometry/Point"],function(a,b,c){return a.createSubclass({declaredClass:"esri.tasks.support.AddressCandidate",properties:{address:{value:null,json:{write:!0}},attributes:{value:null,json:{write:!0}},extent:{value:null,type:b,json:{write:!0}},location:{value:null,type:c,json:{write:!0}},score:{value:null,json:{write:!0}}}})});