// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.10/esri/copyright.txt for details.
//>>built
define("require exports ../../core/tsSupport/declareExtendsHelper ../../core/tsSupport/decorateHelper ../../core/JSONSupport ../../core/accessorSupport/decorators".split(" "),function(g,h,e,d,f,b){return function(c){function a(){var a=null!==c&&c.apply(this,arguments)||this;a.type=null;return a}e(a,c);d([b.property({json:{write:!0}})],a.prototype,"type",void 0);return a=d([b.subclass("esri.tasks.support.ColorRamp")],a)}(b.declared(f))});