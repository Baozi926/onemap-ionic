# maquette-jsx
Use this library to enable JSX in maquette.

## Usage
- Install maquette-jsx by running `npm install maquette-jsx --save`.
- Call `enableJsx` before calling `createProjector`.
- Now you can let your `renderMaquette` functions return JSX!

## Example
https://github.com/AFASSoftware/maquette-typescript-jsx-starter
